import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONObject;

public class ShamirSecretSharing {

    // Method to decode the base and value into decimal
    public static int decodeBase(String base, String value) {
        int baseInt = Integer.parseInt(base);
        return Integer.parseInt(value, baseInt); // Convert value from base to decimal
    }

    // Method to perform Lagrange Interpolation and find the constant term c
    public static int findSecret(int[] xValues, int[] yValues, int k) {
        int secret = 0;
        int n = xValues.length;

        // Lagrange Interpolation for calculating the constant term at x = 0
        for (int i = 0; i < n; i++) {
            int li = 1;
            for (int j = 0; j < n; j++) {
                if (i != j) {
                    li *= (xValues[j] * modInverse(xValues[j] - xValues[i], 256)) % 256;
                    li %= 256;  // Keep the value modulo 256
                }
            }
            secret += (yValues[i] * li) % 256;
            secret %= 256;
        }

        return secret;
    }

    // Helper function to find modular inverse using Extended Euclidean Algorithm
    public static int modInverse(int a, int m) {
        a = a % m;
        int t = 0;
        int newT = 1;
        int r = m;
        int newR = a;

        while (newR != 0) {
            int quotient = r / newR;

            int tempT = t;
            t = newT;
            newT = tempT - quotient * newT;

            int tempR = r;
            r = newR;
            newR = tempR - quotient * newR;
        }

        if (r > 1) {
            throw new ArithmeticException("Modular inverse does not exist");
        }

        if (t < 0) {
            t = t + m;
        }

        return t;
    }

    public static void main(String[] args) {
        try {
            // Parse the input JSON from a file
            File file = new File("test_case.json");
            FileReader reader = new FileReader(file);
            StringBuilder jsonContent = new StringBuilder();
            int i;
            while ((i = reader.read()) != -1) {
                jsonContent.append((char) i);
            }
            reader.close();
            
            JSONObject json = new JSONObject(jsonContent.toString());
            JSONObject keys = json.getJSONObject("keys");
            int n = keys.getInt("n");
            int k = keys.getInt("k");
            
            int m = k - 1; // Degree of the polynomial
            List<Integer> xValues = new ArrayList<>();
            List<Integer> yValues = new ArrayList<>();
            
            // Parse the roots from the JSON data
            Iterator<String> keysIterator = json.keys();
            while (keysIterator.hasNext()) {
                String key = keysIterator.next();
                if (!key.equals("keys")) {
                    JSONObject root = json.getJSONObject(key);
                    String base = root.getString("base");
                    String value = root.getString("value");
                    
                    int x = Integer.parseInt(key); // The key is the x-value
                    int y = decodeBase(base, value); // Decode the y-value from base to decimal
                    
                    xValues.add(x);
                    yValues.add(y);
                }
            }

            // Convert lists to arrays for easier handling
            int[] xArray = xValues.stream().mapToInt(i -> i).toArray();
            int[] yArray = yValues.stream().mapToInt(i -> i).toArray();
            
            // Find the secret (constant term)
            int secret = findSecret(xArray, yArray, k);
            
            // Output the secret (constant term c)
            System.out.println("Secret (constant term c): " + secret);
            
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ArithmeticException e) {
            System.out.println("Error calculating modular inverse: " + e.getMessage());
        }
    }
}
